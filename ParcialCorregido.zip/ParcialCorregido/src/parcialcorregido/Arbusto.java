package parcialcorregido;

public class Arbusto extends Planta implements Podable {
    private static int MIN_DENSIDAD_FOLLAJE = 1;
    private static int MAX_DENSIDAD_FOLLAJE = 10;
    private int densidadFollaje;

    public Arbusto(int densidadFollaje, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        validarDensidadFollaje(densidadFollaje);
        this.densidadFollaje = densidadFollaje;
    }
    
    private void validarDensidadFollaje(int densidadFollaje) {
        if (densidadFollaje < MIN_DENSIDAD_FOLLAJE || densidadFollaje > MAX_DENSIDAD_FOLLAJE) {
            throw new IllegalArgumentException("Valor de densidad de follaje invalida");
        }
    }

    @Override
    public String toString() {
        return "Arbusto{" + "densidadFollaje=" + this.densidadFollaje + super.toString() + '}';
    }

    @Override
    public void podar() {
        System.out.println("El arbusto " + this.getNombre() + " ha sido podado");
    }
    
    
}
