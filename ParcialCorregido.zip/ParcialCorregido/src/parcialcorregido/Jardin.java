package parcialcorregido;

import java.util.ArrayList;
import java.util.List;

public class Jardin {
    private List<Planta> plantas;
    
    public Jardin() {
        this.plantas = new ArrayList<>();
    }
    
    public void agregarPlanta(Planta planta) {
        if (this.plantas.contains(planta)) {
            throw new PlantaExistenteException();
        }
        this.plantas.add(planta);
    }
    
    public void mostrarPlantas() {
        for (Planta planta : this.plantas) {
            System.out.println(planta);
        }
    }
    
    public void podarPlantas() {
        for (Planta planta : this.plantas) {
            if(planta instanceof Podable p) {
                p.podar();
            } else {
                System.out.println("Las flores no requieren de poda");
            }
        }
    }
}
