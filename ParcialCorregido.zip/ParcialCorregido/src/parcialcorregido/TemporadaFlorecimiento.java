package parcialcorregido;

public enum TemporadaFlorecimiento {
    PRIMAVERA, 
    VERANO,
    OTONIO,
    INVIERNO
}
