package parcialcorregido;

import java.util.Objects;

public abstract class Planta {
    private String nombre;
    private String ubicacion;
    private String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getNombre() {
        return this.nombre;
    }
    
    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }
    
    public String getUbicacion() {
        return this.ubicacion;
    }
    
    public void setClima(String clima) {
        this.clima = clima;
    }
    
    public String getClima() {
        return this.clima;
    }

    @Override
    public String toString() {
        return ", nombre=" + this.nombre + ", ubicacion=" + this.ubicacion + ", clima=" + this.clima + '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, ubicacion);
    }

    @Override
    public boolean equals(Object obj) {
        // Pregunta de si la instancia es igual al objeto
        if (this == obj) {
            return true;
        }
        // Pregunta de si el objeto es nulo
        if (obj == null) {
            return false;
        }
        // Pregunta de si el objeto es de tipo Planta
        if (obj instanceof Planta other) {
            //             return nombre.equals(other.nombre) && ubicacion == other.ubicacion;
            return nombre.equals(other.nombre) && ubicacion.equals(other.ubicacion);
        }
        return false;
    }
    
}
