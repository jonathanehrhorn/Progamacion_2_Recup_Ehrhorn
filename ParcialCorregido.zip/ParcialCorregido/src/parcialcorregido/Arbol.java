package parcialcorregido;

public class Arbol extends Planta implements Podable {
    private int alturaMaxima;

    public Arbol(int alturaMaxima, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    @Override
    public String toString() {
        return "Arbol{" + "alturaMaxima=" + alturaMaxima + super.toString() + '}';
    }

    @Override
    public void podar() {
        System.out.println("El arbol " + this.getNombre() + " ha sido podado");
    }
    
    
}
