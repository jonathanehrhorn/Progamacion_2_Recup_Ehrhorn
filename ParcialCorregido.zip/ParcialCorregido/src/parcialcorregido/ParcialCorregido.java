package parcialcorregido;

public class ParcialCorregido {

    public static void main(String[] args) {

        Jardin jardin = new Jardin();
        Planta roble1 = new Arbol(10, "Roble", "Norte", "Frio");
        // Planta roble2 = new Arbol(10, "Roble", "Norte", "Frio");
        Planta arbusto1 = new Arbusto(2, "Arbusto", "Oeste", "Calor");
        Planta flor1 = new Flor(TemporadaFlorecimiento.VERANO, "Rosa", "Sur", "Templado");
        
        jardin.agregarPlanta(roble1);
        // jardin.agregarPlanta(roble2);
        jardin.agregarPlanta(arbusto1);
        jardin.agregarPlanta(flor1);
        
        jardin.mostrarPlantas();
        
        jardin.podarPlantas();
    } 
    
}
