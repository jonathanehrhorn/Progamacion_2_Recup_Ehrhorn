package parcialcorregido;

public class PlantaExistenteException extends RuntimeException {
    private static final String MESSAGE = "La planta ya existe en el jardin";
    
    public PlantaExistenteException() {
        super(MESSAGE);
    }
}
