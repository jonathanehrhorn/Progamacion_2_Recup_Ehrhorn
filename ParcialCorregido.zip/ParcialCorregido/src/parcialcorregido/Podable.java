package parcialcorregido;

public interface Podable {

    void podar();

}
